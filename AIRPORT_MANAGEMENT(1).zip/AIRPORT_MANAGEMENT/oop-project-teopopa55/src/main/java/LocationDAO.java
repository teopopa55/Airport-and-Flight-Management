import java.util.*;
import java.sql.*;

public class LocationDAO extends GeneralDAO{

    public List<String> getAllCountries()
    {
        List<String> results = new ArrayList<>();
        String sql = "SELECT name FROM country ORDER BY name asc";
        try(Connection conn= DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery())
        {
            while (rs.next()) results.add(rs.getString("name"));
        }catch (SQLException e){ throw new RuntimeException(e) ;}
        return results;
    }
    public List<String> getAllCities()
    {
        List<String> results = new ArrayList<>();
        String sql = "SELECT name FROM city ORDER BY name asc";
        try(Connection conn= DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery())
        {
            while (rs.next()) results.add(rs.getString("name"));
        }catch (SQLException e){ throw new RuntimeException(e) ;}
        return results;
    }

    public List<String> getAllStaffNames()
    {
        List<String> results = new ArrayList<>();
        String sql = "SELECT name FROM airport_staff ORDER BY name ASC";
        try( Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()){
            while(rs.next()) results.add(rs.getString("name"));
        }catch (SQLException e){ throw new RuntimeException(e); }
        return results;
    }
    public List<Map<String, Object>> getFlightStaff() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = "SELECT f.id AS flight_number, s.name AS staff_name, fn.functions AS function_name, al.airline_name " +
                "FROM flight f JOIN airline_staff_flight asf ON asf.flight_id = f.id " +
                "JOIN airline_staff s ON s.id = asf.airline_staff_id " +
                "JOIN functions fn ON fn.id = s.function_id " +
                "JOIN airline al ON al.id = s.airline_id ORDER BY f.id, s.name";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("flight_number", rs.getInt("flight_number"));
                map.put("staff_name", rs.getString("staff_name"));
                map.put("function_name", rs.getString("function_name"));
                map.put("airline_name", rs.getString("airline_name"));
                results.add(map);
            }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return results;
    }

    public List<String> getAvailableDepartureCities() {
        List<String> results = new ArrayList<>();
        // Only selects cities that are listed as a departure_city for a future flight
        String sql = "SELECT DISTINCT c.name FROM city c " +
                "JOIN flight f ON c.id = f.departure_city " +
                "WHERE f.day >= CURRENT_DATE ORDER BY c.name ASC";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) results.add(rs.getString("name"));
        } catch (SQLException e) { throw new RuntimeException(e); }
        return results;
    }

    public List<String> getAvailableArrivalCities(String depCity) {
        List<String> results = new ArrayList<>();
        // Optional: Filter arrival cities based on the departure city chosen
        String sql = "SELECT DISTINCT c.name FROM city c " +
                "JOIN flight f ON c.id = f.arrival_city " +
                "JOIN city dc ON dc.id = f.departure_city " +
                "WHERE f.day >= CURRENT_DATE AND dc.name = ? ORDER BY c.name ASC";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, depCity);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) results.add(rs.getString("name"));
            }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return results;
    }

    public List<Map<String, String>> getStaffForDropdown(){
        List<Map<String,String>> results = new ArrayList<>();
        String sql = "SELECT a.name, f.functions FROM airport_staff a JOIN functions f ON f.id = a.function_id";
        try( Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Map<String, String> staff = new HashMap<>();
                staff.put("name", rs.getString("name"));
                staff.put("function", rs.getString("functions"));
                results.add(staff);
            }
        }catch(SQLException e){ throw new RuntimeException(e); }
        return results;
    }

}