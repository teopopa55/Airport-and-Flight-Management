import java.util.*;
import java.sql.*;

public class FlightDAO extends GeneralDAO {

    //queries from dbeaver that serve for flight information page
    //all queries found in dbeaver scripts
    public List<Map<String,Object>>getPastFlightInfo()
    {
        String sql = "SELECT al.airline_code, f.id AS flight_id, dc.name AS departure_city, "+
                     "ac.name AS arrival_city, f.day, f.take_off_time, f.landing_time, al.airline_name "+
                     "FROM flight f JOIN airline al ON al.id=f.airline_id "+
                     "JOIN city dc ON dc.id = f.departure_city "+
                     "JOIN city ac ON ac.id = f.arrival_city WHERE f.day < CURRENT_DATE";
        return executeFlightQuery(sql);
    }
    public List<Map<String,Object>>getFutureFlightInfo()
    {
        String sql = "SELECT al.airline_code, f.id AS flight_id, dc.name AS departure_city, "+
                "ac.name AS arrival_city, f.day, f.take_off_time, f.landing_time, al.airline_name "+
                "FROM flight f JOIN airline al ON al.id=f.airline_id "+
                "JOIN city dc ON dc.id = f.departure_city "+
                "JOIN city ac ON ac.id = f.arrival_city WHERE f.day > CURRENT_DATE";
        return executeFlightQuery(sql);
    }

    public List<Map<String, Object>> getFlightStaff() {
        List<Map<String, Object>> results = new ArrayList<>();

        String sql = "SELECT f.id AS flight_number, s.name AS staff_name, fn.functions AS function_name, al.airline_name " +
                "FROM flight f " +
                "JOIN airline_staff_flight asf ON asf.flight_id = f.id " +
                "JOIN airline_staff s ON s.id = asf.airline_staff_id " +
                "JOIN functions fn ON fn.id = s.function_id " +
                "JOIN airline al ON al.id = s.airline_id " +
                "ORDER BY f.id";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("flight_number", rs.getInt("flight_number"));
                map.put("staff_name", rs.getString("staff_name"));
                map.put("function_name", rs.getString("function_name"));
                map.put("airline_name", rs.getString("airline_name"));
                results.add(map);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching crew details: " + e.getMessage()); // Better error message
        }
        return results;
    }

    private List<Map<String, Object>> executeFlightQuery (String sql){
        List<Map<String, Object>> results = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("airline_code", rs.getString("airline_code"));
                map.put("flight_id", rs.getInt("flight_id"));
                map.put("departure_city", rs.getString("departure_city"));
                map.put("arrival_city", rs.getString("arrival_city"));
                map.put("day", rs.getDate("day").toString());
                map.put("take_off_time", rs.getTime("take_off_time").toString());
                map.put("landing_time", rs.getTime("landing_time").toString());
                map.put("airline_name", rs.getString("airline_name"));
                results.add(map);
            }
        }catch(SQLException e) {
             throw new RuntimeException(e);
        }
        return results;
    }

}