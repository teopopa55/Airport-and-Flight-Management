public class Shift {
    public String check_In;
    public String check_out;

    public Shift(String check_In, String check_out) {
        this.check_In = check_In;
        this.check_out = check_out;
    }

    public String getCheck_In() {
        return check_In;
    }

    public String getCheck_out() {
        return check_out;
    }
}
