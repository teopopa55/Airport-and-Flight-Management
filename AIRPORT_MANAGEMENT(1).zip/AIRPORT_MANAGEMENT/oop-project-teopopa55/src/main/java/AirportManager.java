import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AirportManager {
    List<Country> countries = new ArrayList<>();
    List<City> cities = new ArrayList<>();
    List<Airline> airlines = new ArrayList<>();
    Functions[] functions = new Functions[9];
    List<Airport_staff> airport_staff = new ArrayList<>();
    List<Passenger> passengers = new ArrayList<>();
    List<List<Airline_Staff>> airline_staff = new ArrayList<>();
    List<Flight> flights = new ArrayList<>();
    List<Integer> reservation_nr = new ArrayList<>();
    //SHIFTS
    List<Shift> times= new ArrayList<>();
    Map<Airport_staff, Shift> shifts = new HashMap<>();
    //RESERVATIONS
    Map<Integer, Passenger> reservation_passenger= new HashMap<>();
    public void FlightInfo() {
        System.out.println("\nFlight Information: ");
        for (Flight f : flights) {
            f.FlightDetails();
        }
    }

    public void PassengerInfo( ) {
        System.out.println("\nPassenger Information:");
        for (Passenger p : passengers) {
            p.getDescription();
        }
    }

    public void Bookaflight( String name, int cnp, String country, int departure, int arrival) {
        Passenger p = new Passenger(name, cnp, country);
        passengers.add(p);
        int new_res = 0;
        for (Integer i : reservation_nr) {
            new_res = i;
        }
        new_res++;
        reservation_nr.add(new_res);
        reservation_passenger.put(new_res, p);
        System.out.println("\nReservation number: " + new_res);
    }

    public void AirportDetails() {
        System.out.println("\nAirport Staff and Shift details: ");
        for (Map.Entry<Airport_staff, Shift> s : shifts.entrySet()) {
            int f_id = s.getKey().getFunction_id();
            String name;
            if (f_id == 4) name = "Boarder Officer";
            else name = "Operator";
            System.out.println("Name: " + s.getKey().getName() + " | Function: " + name + " | Shift: " + s.getValue().getCheck_In() + " - " + s.getValue().getCheck_out());
        }
    }

    public void AirlineDetails() {
        System.out.println("\nCabin crews details: ");
        for (List<Airline_Staff> airlineList : airline_staff) {
            for (Airline_Staff staff : airlineList) {
                int f_id = staff.getFunction_id();
                int a_id = staff.getAirline_id();
                String name="error";
                String airline;
                if (f_id == 1) name = "Pilot";
                if (f_id == 2) name = "Copilot";
                if(f_id==3) name = "Stewardese";
                if (a_id == 1) airline = "WizzAir";
                else airline = "Ryanair";
                System.out.println("Name: " + staff.getName() + " | Function: " + name + " | Airline: " + airline);
            }
        }


    }

    public void SearchResPass(int nr)
    {
        Passenger p=reservation_passenger.get(nr);
        if(p!=null)
        {

            p.getDescription();
        }
        else System.out.println("Passenger NOT FOUND.");

    }
}