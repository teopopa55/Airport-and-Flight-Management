import java.sql.*;
import java.util.*;

//for inheritance and encapsulation for all DAOs
public abstract class GeneralDAO
{

    protected Connection getConnection() throws SQLException{
        return DatabaseConnection.getConnection();
    }

    protected List<Map<String, Object>>executeQuery(String sql, Object...params)
    {
        List<Map<String,Object>>results =new ArrayList<>();
        try (Connection conn= getConnection();
             PreparedStatement pstmt=conn.prepareStatement(sql))
        {
            for(int i=0;i< params.length;i++)
            {
                pstmt.setObject(i+1,params[i]);
            }

            try(ResultSet rs = pstmt.executeQuery())
            {
                ResultSetMetaData metaData=rs.getMetaData();
                int columnCount= metaData.getColumnCount();

                while(rs.next()) {
                    Map<String, Object> row = new HashMap<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.put(metaData.getColumnLabel(i).toLowerCase(), rs.getObject(i));
                    }
                    results.add(row);
                }
            }

        } catch (SQLException e){
            throw new RuntimeException("Database execution error: "+e.getMessage());
        }
        return results;
    }
}
