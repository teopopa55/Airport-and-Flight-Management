public class Passenger extends Person{

    //Encapsulation: private fields
    private int cnp;
    private String country;


    public Passenger(String name,  int cnp, String country) {
        super(name);
        this.cnp = cnp;
        this.country = country;
    }

    //Encapsulation: public methods
    public String getCountry_id() {
        return country;
    }

    public int getCnp() {
        return cnp;
    }

    @Override
    public void getDescription()
    {
        System.out.println("Passenger: "+ getName()+" | CNP: "+cnp+" | Nationality: "+ country);
    }
}