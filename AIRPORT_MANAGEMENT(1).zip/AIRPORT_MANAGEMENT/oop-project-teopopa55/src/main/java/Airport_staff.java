public class Airport_staff extends Staff
{
    public Airport_staff( String name, int function_id) {
        super( name, function_id);

    }

    @Override
    public void getDescription()
    {
        System.out.println("Airport Staff: "+ getName());
    }
}
