public class Airline_Staff extends Staff
{
    //Encapsulation: private fields
    private int airline_id;


    public Airline_Staff(String name, int function_id, int airline_id) {
        super(name, function_id);
        this.airline_id = airline_id;
    }

    public int getAirline_id() {
        return airline_id;
    }

    @Override
    public void getDescription()
    {

    }
}
