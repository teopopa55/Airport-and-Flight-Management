import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Demo {
    public static void main (String[] args) {
        AirportManager airport = new AirportManager();

        airport.countries.add(new Country(1, "Romania"));
        airport.countries.add(new Country(2, "France"));
        airport.countries.add(new Country(3, "United Kingdom"));

        airport.cities.add(new City(1, "Cluj-Napoca"));
        airport.cities.add(new City(2, "London"));
        airport.cities.add(new City(3, "Nice"));

        airport.airlines.add(new Airline(1, "WizzAir"));
        airport.airlines.add(new Airline(2, "Ryanair"));

        airport.functions[0] = new Functions(1, "Pilot");
        airport.functions[1] = new Functions(2, "Copilot");
        airport.functions[2] = new Functions(3, "Stewardese");
        airport.functions[3] = new Functions(4, "Boarder Officer");
        airport.functions[4] = new Functions(5, "Operator");

        List<Airline_Staff> cabin_crew_wizz = new ArrayList<>();
        List<Airline_Staff> cabin_crew_ryan = new ArrayList<>();

        cabin_crew_wizz.add(new Airline_Staff("Anastasia Michael", 3, 1));
        cabin_crew_wizz.add(new Airline_Staff("Ariana Smith", 3, 1));
        cabin_crew_wizz.add(new Airline_Staff("Adrian Lim", 1, 1));
        cabin_crew_wizz.add(new Airline_Staff("Josh Titman", 2, 1));
        cabin_crew_ryan.add(new Airline_Staff("Kateria Ivanova", 3, 2));
        cabin_crew_ryan.add(new Airline_Staff("Alys Myth", 3, 2));
        cabin_crew_ryan.add(new Airline_Staff("Alex Taurean", 1, 2));
        cabin_crew_ryan.add(new Airline_Staff("Alan Viv", 2, 2));
        airport.airline_staff.add(cabin_crew_wizz);
        airport.airline_staff.add(cabin_crew_ryan);

        airport.airport_staff.add(new Airport_staff("Jack Morton", 4));
        airport.airport_staff.add(new Airport_staff("Peter Morton", 4));
        airport.airport_staff.add(new Airport_staff("Edward Coventry", 5));
        airport.airport_staff.add(new Airport_staff("Liana Magus", 5));

        airport.passengers.add(new Passenger("Lily Adams", 200201, "Romania"));
        airport.passengers.add(new Passenger("James Bell", 200202, "United Kingdom"));
        airport.passengers.add(new Passenger("Chloe Carter", 200203, "France"));

        airport.flights.add(new Flight(1, "Cluj-Napoca", "London", "05-01-2026", "08:00:00", "10:30:00", "Ryanair", 54));
        airport.flights.add(new Flight(2, "Cluj-Napoca", "Nice", "05-01-2026", "18:00:00", "20:30:00", "WizzAir", 54));

        airport.flights.add(new Flight(3, "London", "Cluj-Napoca", "05-01-2026", "11:00:00", "13:30:00", "Ryanair", 54));
        airport.flights.add(new Flight(4, "Nice", "Cluj-Napoca", "05-01-2026", "14:00:00", "16:30:00", "WizzAir", 54));

        airport.times.add(new Shift("00:00:00", "08:00:00"));
        airport.times.add(new Shift("08:00:00", "16:00:00"));
        airport.times.add(new Shift("16:00:00", "00:00:00"));

        airport.shifts.put(airport.airport_staff.get(0), airport.times.get(0));
        airport.shifts.put(airport.airport_staff.get(1), airport.times.get(2));
        airport.shifts.put(airport.airport_staff.get(2), airport.times.get(1));
        airport.shifts.put(airport.airport_staff.get(3), airport.times.get(2));

        airport.reservation_nr.add(1000);
        airport.reservation_passenger.put(997, new Passenger("Lily Adams", 200201, "Romania") );
        airport.reservation_passenger.put(998, new Passenger("James Bell", 200202, "United Kingdom") );
        airport.reservation_passenger.put(999, new Passenger("Chloe Carter", 200203, "France") );

        Scanner input = new Scanner(System.in);

        System.out.println("\nMenu: ");
        System.out.println("1.Flight Information.");
        System.out.println("2.Passenger Information.");
        System.out.println("3.Book a flight.");
        System.out.println("4.Search Passenger by Reservation Number.");
        System.out.println("5.Airport Staff Information.");
        System.out.println("6.Cabin Crew Information.");
        System.out.println("7.Exit.");
        System.out.println("\nPlease choose a functionality: (type the number)");

        while (true)
        {
            int functionality = input.nextInt();
            if(functionality==7) break;
            switch (functionality) {
                case 1: {
                    airport.FlightInfo();
                    break;
                }
                case 2: {
                    airport.PassengerInfo();
                    break;
                }
                case 3: {
                    System.out.println("\nPlease introduce the name: ");
                    String name = input.next();
                    System.out.println("\nPlease introduce the CNP: ");
                    int cnp = input.nextInt();
                    System.out.println("\nPlease introduce the nationality/country: ");
                    String country = input.next();
                    System.out.println("\nChoose the digit for the city departure: ");
                    int i = 1;
                    for (City c : airport.cities) {
                        System.out.println(i + ". ");
                        c.getLocName();
                        i++;
                    }
                    int dep = input.nextInt();
                    int arr;
                    if (dep != 1) {
                        System.out.println("The arrival city will be Cluj-Napoca.");
                        arr = 1;
                    } else {
                        i = 1;
                        System.out.println("\nChoose the digit for the city arrival: ");
                        for (City c : airport.cities) {
                            System.out.println(i + ". ");
                            c.getLocName();
                            i++;
                        }
                        arr = input.nextInt();
                    }
                    airport.Bookaflight(name, cnp, country, dep, arr);
                    break;
                }
                case 4: {
                    System.out.println("\nPlease introduce the reservation number: ");
                    int nr= input.nextInt();
                    airport.SearchResPass(nr);
                    break;
                }
                case 5: {
                    airport.AirportDetails();
                    break;
                }
                case 6: {
                    airport.AirlineDetails();
                    break;
                }
                default: {
                    System.out.println("\nWrong digit.");
                    break;
                }
            }
        }
    }
}
