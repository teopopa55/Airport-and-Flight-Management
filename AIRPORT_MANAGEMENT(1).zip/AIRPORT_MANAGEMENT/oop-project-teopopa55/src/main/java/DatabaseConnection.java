import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection
{
    private static final String URL ="jdbc:postgresql://localhost:5432/airport_and_flight_management";
    private static final String USER= "postgres";
    private static final String PASSWORD="Mihaela35";

    public static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(URL,USER,PASSWORD);
    }
}
