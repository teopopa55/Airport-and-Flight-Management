import static spark.Spark.*;
import com.google.gson.Gson;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class AIRPORTCONTROLLER {

    private FlightDAO flightDAO = new FlightDAO();
    private PassengerDAO passengerDAO = new PassengerDAO();
    private StaffDAO staffDAO = new StaffDAO();
    private BookAFlightDAO bookAFlightDAO = new BookAFlightDAO();
    private LocationDAO locationDAO = new LocationDAO();
    private Gson gson = new Gson();

    public void initEndpoints() {

        // --- ROOT REDIRECT ---
        get("/", (req, res) -> {
            res.redirect("/webpage.html");
            return null;
        });

        // --- 1. FLIGHT INFORMATION ---
        // 1a. Previous Flights (Matches keys: airline_code, flight_id, departure_city, etc.)
        get("/flight/past", (req, res) -> {
            res.type("application/json");
            return gson.toJson(flightDAO.getPastFlightInfo());
        });

        // 1b. Upcoming Flights
        get("/flight/future", (req, res) -> {
            res.type("application/json");
            return gson.toJson(flightDAO.getFutureFlightInfo());
        });

        // 1c. Flight Personnel Info
        get("/flight/crew", (req, res) -> {
            res.type("application/json");
            return gson.toJson(flightDAO.getFlightStaff());
        });

        // --- 2. SHIFTS ---
        // 2a. View Personnel Shifts (Matches keys: employeeName, role, shiftDay, etc.)
        get("/staff/shifts", (req, res) -> {
            res.type("application/json");
            return gson.toJson(staffDAO.getStaffShifts());
        });

        // 2b. Add Shift Details
        post("/staff/addshift", (req, res) -> {
            try {
                staffDAO.addStaffShift(
                        req.queryParams("name"),
                        req.queryParams("day"),
                        req.queryParams("checkIn"),
                        req.queryParams("checkOut")
                );
                res.status(201);
                return "Shift added successfully!";
            } catch (Exception e) {
                res.status(400);
                return "Failed to add shift: " + e.getMessage();
            }
        });

        // --- 3. PASSENGER INFORMATION ---
        // 3a. Previous Passengers (Matches keys: reservation_number, passenger_name, etc.)
        get("/passenger/past", (req, res) -> {
            res.type("application/json");
            return gson.toJson(passengerDAO.getPastPassengers());
        });

        // 3b. Upcoming Passengers
        get("/passenger/future", (req, res) -> {
            res.type("application/json");
            return gson.toJson(passengerDAO.getFuturePassengers());
        });

        // 3c. Search Passenger by Reservation ID
        get("/reservation/:id", (req, res) -> {
            try {
                int id = Integer.parseInt(req.params(":id"));
                res.type("application/json");
                Object result = passengerDAO.findPassengerByReservationNumber(id);
                if (result == null) {
                    res.status(404);
                    return "Reservation not found.";
                }
                return gson.toJson(result);
            } catch (Exception e) {
                res.status(400);
                return "Error: " + e.getMessage();
            }
        });

        // --- 4. BOOK A FLIGHT ---
        // 4a. Make a Reservation
        // Updated to receive and return the Success String from BookAFlightDAO

        post("/reservation/make", (req, res) -> {
            try {
                String reservationMessage = bookAFlightDAO.createReservation(
                        req.queryParams("name"),
                        Integer.parseInt(req.queryParams("cnp")),
                        req.queryParams("countryName"),
                        req.queryParams("departureCity"),
                        req.queryParams("arrivalCity")
                );

                res.status(201);
                return reservationMessage;

            } catch (Exception e) {
                e.printStackTrace();
                res.status(400);
                return "Reservation failed";
            }
        });



        get("/available-departures", (req, res) -> {
            res.type("application/json");
            return gson.toJson(locationDAO.getAvailableDepartureCities());
        });

        get("/available-arrivals", (req, res) -> {
            String dep = req.queryParams("departure");
            res.type("application/json");
            return gson.toJson(locationDAO.getAvailableArrivalCities(dep));
        });



        // 4b. Available Flights (Matches keys: departure_city_name, seats_taken, etc.)
        get("/flight/available", (req, res) -> {
            res.type("application/json");
            return gson.toJson(bookAFlightDAO.getAvailableFlights());
        });

        // 4c. Non-available Flights (Full Flights)
        get("/flight/full", (req, res) -> {
            res.type("application/json");
            return gson.toJson(bookAFlightDAO.getNonAvailableFlights());
        });

        // --- 5. HELPER ENDPOINTS (For Dropdowns) ---
        get("/countries", (req, res) -> {
            res.type("application/json");
            return gson.toJson(locationDAO.getAllCountries());
        });

        get("/cities", (req, res) -> {
            res.type("application/json");
            return gson.toJson(locationDAO.getAllCities());
        });

        get("/staff/list", (req, res) -> {
            res.type("application/json");
            return gson.toJson(locationDAO.getAllStaffNames());
        });
    }
}