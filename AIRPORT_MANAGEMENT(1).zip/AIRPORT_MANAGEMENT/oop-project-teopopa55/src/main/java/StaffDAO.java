import java.sql.*;
import java.util.*;

public class StaffDAO extends GeneralDAO {

    // 2a. VIEW PERSONNEL SHIFTS
    public List<Map<String, Object>> getStaffShifts() {
        List<Map<String, Object>> results = new ArrayList<>();
        // Query 2: Personnel Shifts including day
        String sql = "SELECT a.name AS staff_name, f.functions, s.day, s.check_in, s.check_out " +
                "FROM airport_staff a " +
                "JOIN functions f ON f.id = a.function_id " +
                "JOIN airport_staff_shift ass ON ass.airport_staff_id = a.id " +
                "JOIN shift s ON s.id = ass.shift_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> shift = new HashMap<>();
                // Keys matched to HTML property names
                shift.put("employeeName", rs.getString("staff_name"));
                shift.put("role", rs.getString("functions"));
                shift.put("shiftDay", rs.getDate("day").toString()); // Added Date
                shift.put("startTime", rs.getTime("check_in").toString());
                shift.put("endTime", rs.getTime("check_out").toString());
                results.add(shift);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching shifts: " + e.getMessage());
        }
        return results;
    }

    // 2b. INTRODUCE SHIFT DETAILS
    public void addStaffShift(String name, String day, String checkIn, String checkOut) {
        String sql = "SELECT add_airport_staff_shift(?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setDate(2, java.sql.Date.valueOf(day)); // Fixed ambiguity
            pstmt.setTime(3, java.sql.Time.valueOf(checkIn + ":00"));
            pstmt.setTime(4, java.sql.Time.valueOf(checkOut + ":00"));
            pstmt.execute();
        } catch (SQLException e) {
            if ("P0001".equals(e.getSQLState())) {
                throw new RuntimeException("Scheduling Conflict: " + e.getMessage());
            } else {
                throw new RuntimeException("Database Error: " + e.getMessage());
            }
        }
    }
}