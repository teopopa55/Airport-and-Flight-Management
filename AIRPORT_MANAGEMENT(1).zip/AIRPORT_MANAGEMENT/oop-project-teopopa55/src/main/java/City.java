public class City extends Location{

    public City(int id, String name) {
        super(id, name);
    }



    @Override
    public void getLocName()
    {
        System.out.println(getName());
    }


}
