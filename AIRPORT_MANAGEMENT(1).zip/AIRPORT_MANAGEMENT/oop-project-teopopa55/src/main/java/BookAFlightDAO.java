import java.sql.*;
import java.util.*;

public class BookAFlightDAO extends GeneralDAO{

    public List<Map<String, Object>> getAvailableFlights() {
        String sql = "SELECT f.id, dc.name AS departure_city, ac.name AS arrival_city, " +
                "f.day, f.take_off_time, f.landing_time, al.airline_name, f.max_passenger, " +
                "(SELECT COUNT(*) FROM reservation_number rn WHERE rn.flight_id = f.id) AS seats_taken " +
                "FROM flight f JOIN city dc ON dc.id = f.departure_city " +
                "JOIN city ac ON ac.id = f.arrival_city " +
                "JOIN airline al ON al.id = f.airline_id " +
                "WHERE f.day >= CURRENT_DATE AND " +
                "(SELECT COUNT(*) FROM reservation_number rn WHERE rn.flight_id = f.id) < f.max_passenger";

        return executeFlightQuery(sql, true);
    }

    public List<Map<String, Object>> getNonAvailableFlights() {
        String sql = "SELECT f.id, dc.name AS departure_city, ac.name AS arrival_city, " +
                "f.day, f.take_off_time, f.landing_time, al.airline_name, f.max_passenger, " +
                "(SELECT COUNT(*) FROM reservation_number rn WHERE rn.flight_id = f.id) AS seats_taken " +
                "FROM flight f JOIN city dc ON dc.id = f.departure_city " +
                "JOIN city ac ON ac.id = f.arrival_city " +
                "JOIN airline al ON al.id = f.airline_id " +
                "WHERE f.day >= CURRENT_DATE AND " +
                "(SELECT COUNT(*) FROM reservation_number rn WHERE rn.flight_id = f.id) >= f.max_passenger";

        return executeFlightQuery(sql, false);
    }

    public String createReservation(String name, int cnp, String countryName,
                                    String depCity, String arrCity) {

        int flightID = findFlightIDByRoute(depCity, arrCity);
        int countryID = findCountryIDByName(countryName);

        String sql = "SELECT * FROM make_reservation(?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setInt(2, cnp);
            ps.setInt(3, countryID);
            ps.setInt(4, flightID);

            try(ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "SUCCESS | Reservation Number: " + rs.getInt("out_res_number")
                            + " | Seat row: " + rs.getInt("out_seat_row")
                            + " | Seat letter: " + rs.getString("out_seat_letter");
                }
            }
            return "Reservation failed";

        } catch (SQLException e) {
            //e.printStackTrace();
            //return "Reservation failed";
            return "ERROR: "+e.getMessage();
        }
    }


    // Helper: find flight ID by departure and arrival city
    private int findFlightIDByRoute(String departure, String arrival) {
        String sql = "SELECT f.id FROM flight f " +
                "JOIN city dc ON dc.id = f.departure_city " +
                "JOIN city ac ON ac.id = f.arrival_city " +
                "WHERE dc.name = ? AND ac.name = ? LIMIT 1";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, departure);
            ps.setString(2, arrival);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("id");
            throw new RuntimeException("No flight found for this route.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Helper: get country ID by name
    private int findCountryIDByName(String name) {
        String sql = "SELECT id FROM country WHERE name = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("id");
            return 1; // default country ID if not found
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    private List<Map<String, Object>> executeFlightQuery(String sql, boolean isAvailable) {
        List<Map<String, Object>> results = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> f = new HashMap<>();
                f.put("id", rs.getInt("id"));
                f.put("day", rs.getDate("day").toString());
                f.put("departure_city_name", rs.getString("departure_city"));
                f.put("arrival_city_name", rs.getString("arrival_city"));
                f.put("take_off_time", rs.getTime("take_off_time").toString());
                f.put("landing_time", rs.getTime("landing_time").toString());
                f.put("airline_name", rs.getString("airline_name"));
                f.put("max_passenger", rs.getInt("max_passenger"));
                f.put("seats_taken", rs.getInt("seats_taken"));

                results.add(f);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Query error: " + e.getMessage());
        }
        return results;
    }


}