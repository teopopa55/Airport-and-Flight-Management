import static spark.Spark.*;

public class AIRPORTAPPLICATION {

    public static void main(String[] args) {
        // Set server port
        port(4567);

        // Serve static files from the "public" folder in resources
        staticFiles.location("/public");

        // Initialize controller
        AIRPORTCONTROLLER controller = new AIRPORTCONTROLLER();
        controller.initEndpoints();

        System.out.println("Airport Server is running!");
        System.out.println("Go to http://localhost:4567/webpage.html"); //redirect to "menu page"

        // Global exception handler
        exception(Exception.class, (e, req, res) -> {
            res.status(500);
            res.body("Application Error: " + e.getMessage());
            e.printStackTrace();
        });
    }
}
