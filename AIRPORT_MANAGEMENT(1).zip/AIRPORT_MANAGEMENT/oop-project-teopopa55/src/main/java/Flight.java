
import java.util.List;
public class Flight {

    //Encapsulation: private fields
    private int id;
    private String departure_city;
    private String arrival_city;
    private String day;
    private String take_off;
    private String landing_time;
    private String airline;
    private int max_passenger;           //is always 54

    //Composition: flight has a collection of cabin crew members
    //in my database the connection is made through the table airline_staff_flight
    private List<Airline_Staff> crew;

    public Flight(int id, String arrival_city, String departure_city, String day, String take_off, String landing_time, String airline, int max_passenger) {
        this.id = id;
        this.arrival_city = arrival_city;
        this.departure_city = departure_city;
        this.day = day;
        this.take_off = take_off;
        this.landing_time = landing_time;
        this.airline = airline;
        this.max_passenger = max_passenger;
    }

    public void FlightDetails()
    {
        System.out.println("ID: "+id+" | Departure: "+ departure_city+ " | Arrival: "+ arrival_city+" | Day: "+
                            day +" | Take-Off: "+take_off+" | Landing: "+landing_time+" | Airline: "+airline
                            +" | Max Passengers: "+max_passenger);

    }

    //Encapsulation: public methods

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeparture_city() {
        return departure_city;
    }

    public void setDeparture_city(String departure_city) {
        this.departure_city = departure_city;
    }

    public String getArrival_city() {
        return arrival_city;
    }

    public void setArrival_city(String arrival_city) {
        this.arrival_city = arrival_city;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTake_off() {
        return take_off;
    }

    public void setTake_off(String take_off) {
        this.take_off = take_off;
    }

    public String getLanding_time() {
        return landing_time;
    }

    public void setLanding_time(String landing_time) {
        this.landing_time = landing_time;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public int getMax_passenger() {
        return max_passenger;
    }

    public void setMax_passenger(int max_passenger) {
        this.max_passenger = max_passenger;
    }

    public List<Airline_Staff> getCrew() {return crew;}
    public void addCrewMembers(Airline_Staff staff) { this.crew.add(staff); }

}
