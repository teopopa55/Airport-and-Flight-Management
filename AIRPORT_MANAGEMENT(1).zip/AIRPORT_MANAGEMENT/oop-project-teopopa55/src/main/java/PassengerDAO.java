import java.util.*;
import java.sql.*;

public class PassengerDAO extends GeneralDAO{

    public List<Map<String, Object>> getPastPassengers() {
        List<Map<String, Object>> results = new ArrayList<>();
        // Updated SQL: joined the country table and selected country name
        String sql = "select rn.reservation_number, p.name as passenger_name, p.cnp, c.name as country_name, " +
                "f.day, f.take_off_time, f.landing_time, " +
                "dc.name as departure_city, ac.name as arrival_city, rp.seat_number, rp.seat_letter " +
                "from reservation_number rn " +
                "join passenger p on p.id = rn.passenger_id " +
                "join country c on c.id = p.country_id " +
                "join flight f on f.id = rn.flight_id " +
                "join reservation_passenger rp on rp.reservation_number_id = rn.reservation_number " +
                "join city dc on dc.id = f.departure_city " +
                "join city ac on ac.id = f.arrival_city " +
                "where f.day < current_date";

        try (Connection conn = getConnection(); // Using standardized connection method
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> p = new HashMap<>();
                p.put("reservation_number", rs.getInt("reservation_number"));
                p.put("passenger_name", rs.getString("passenger_name"));
                p.put("cnp", rs.getInt("cnp"));
                p.put("country_name", rs.getString("country_name")); // New field added
                p.put("day", rs.getDate("day").toString());
                p.put("take_off_time", rs.getTime("take_off_time").toString());
                p.put("landing_time", rs.getTime("landing_time").toString());
                p.put("departure_city", rs.getString("departure_city"));
                p.put("arrival_city", rs.getString("arrival_city"));
                p.put("seat_number", rs.getInt("seat_number"));
                p.put("seat_letter", rs.getString("seat_letter"));
                results.add(p);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
        return results;
    }

    public List<Map<String, Object>> getFuturePassengers() {
        List<Map<String, Object>> results = new ArrayList<>();

        // Added ORDER BY rn.reservation_number ASC at the end
        String sql = "SELECT rn.reservation_number, p.name AS passenger_name, p.cnp, c.name AS country_name, " +
                "f.day, f.take_off_time, f.landing_time, " +
                "dc.name AS departure_city, ac.name AS arrival_city, rp.seat_number, rp.seat_letter " +
                "FROM reservation_number rn " +
                "JOIN passenger p ON p.id = rn.passenger_id " +
                "JOIN country c ON c.id = p.country_id " +
                "JOIN flight f ON f.id = rn.flight_id " +
                "JOIN city dc ON dc.id = f.departure_city " +
                "JOIN city ac ON ac.id = f.arrival_city " +
                "LEFT JOIN reservation_passenger rp ON rp.reservation_number_id = rn.reservation_number " +
                "WHERE f.day >= CURRENT_DATE " +
                "ORDER BY rn.reservation_number ASC"; // Sorts by Reservation Number

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> p = new HashMap<>();
                p.put("reservation_number", rs.getInt("reservation_number"));
                p.put("passenger_name", rs.getString("passenger_name"));
                p.put("cnp", rs.getObject("cnp"));
                p.put("country_name", rs.getString("country_name"));
                p.put("day", rs.getDate("day").toString());
                p.put("take_off_time", rs.getTime("take_off_time").toString());
                p.put("landing_time", rs.getTime("landing_time").toString());
                p.put("departure_city", rs.getString("departure_city"));
                p.put("arrival_city", rs.getString("arrival_city"));

                // Handle null seats for new reservations
                Object seatNum = rs.getObject("seat_number");
                p.put("seat_number", (seatNum != null) ? seatNum : "Pending");

                String seatLet = rs.getString("seat_letter");
                p.put("seat_letter", (seatLet != null) ? seatLet : "-");

                results.add(p);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching ordered future passengers: " + e.getMessage());
        }
        return results;
    }


    public Map<String, Object> findPassengerByReservationNumber(int reservationNumber) {
        String sql = "SELECT * FROM get_reservation_info(?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, reservationNumber);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Map<String, Object> p = new HashMap<>();
                p.put("reservation_number", rs.getInt("reservation_number"));
                p.put("passenger_name", rs.getString("passenger_name"));
                p.put("name", rs.getString("passenger_name")); // for HTML safety
                p.put("cnp", rs.getObject("cnp"));
                p.put("departure_city", rs.getString("departure_city"));
                p.put("arrival_city", rs.getString("arrival_city"));
                p.put("day", rs.getDate("day").toString());
                p.put("take_off_time", rs.getTime("take_off_time").toString());
                p.put("landing_time", rs.getTime("landing_time").toString());
                p.put("airline", rs.getString("airline_name"));

                // Seat info
                Object seatNum = rs.getObject("seat_number");
                p.put("seat_number", (seatNum != null) ? seatNum : "Pending");

                String seatLet = rs.getString("seat_letter");
                p.put("seat_letter", (seatLet != null) ? seatLet : "-");

                return p;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching passenger: " + e.getMessage());
        }

        return null;
    }

}