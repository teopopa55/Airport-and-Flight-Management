public class Functions {
    public int id;
    public String function;

    public Functions(int id, String function) {
        this.id = id;
        this.function = function;
    }

    public String getFunction() {
        return function;
    }

    public int getId() {
        return id;
    }
}
