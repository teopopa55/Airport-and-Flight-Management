public abstract class Staff extends Person{

    //Encapsulation: private fields
    private int function_id;

    public Staff(String name, int function_id) {
        super(name);
        this.function_id = function_id;
    }

    public int getFunction_id() {
        return function_id;
    }

}