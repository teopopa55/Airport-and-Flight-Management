public class Country extends Location{

    public Country(int id, String name) {
        super(id, name);
    }

    @Override
    public void getLocName()
    {
        System.out.println(getName());
    }
}
